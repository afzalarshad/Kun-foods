# Kun Foods — E-commerce Site (Prompt 1: Setup & Design System)

## Getting started

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## What's in this prompt

- Next.js 14 App Router + TypeScript + Tailwind CSS + Framer Motion
- Design tokens (colors/fonts) as CSS variables in `app/globals.css`
- Reusable UI kit in `components/ui`: Button, Card, Input, Modal, Badge, Toast
- Custom cursor (`components/layout/CustomCursor.tsx`), auto-disabled on touch
- Navbar + Footer with mobile slide-in menu
- `/privacy-policy` and `/terms` pages with full legal copy
- Mock product data in `lib/mock-data.ts` — swap for Supabase queries later

## Logo

Drop your final logo file in at `public/logo.png`, replacing the
placeholder. No code changes needed — `components/layout/Logo.tsx` sizes
itself from the file's real aspect ratio.

## Next prompts

This is prompt 1 of 5. Later prompts will build out the home page hero and
sections, the shop/PLP/PDP pages, cart & checkout flow, and Supabase wiring.
