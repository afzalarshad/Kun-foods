import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Terms & Conditions | Kun Foods",
};

export default function TermsPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-16 sm:px-6 lg:px-8">
      <h1 className="font-display text-3xl font-extrabold sm:text-4xl">Terms &amp; Conditions</h1>
      <p className="mt-2 text-sm text-tandoor/60">Last updated: August 2026</p>

      <div className="prose mt-8 max-w-none prose-headings:font-display prose-headings:font-bold prose-a:text-chili">
        <p>
          These Terms &amp; Conditions (&ldquo;Terms&rdquo;) govern your access to and use
          of kunfoods.pk (the &ldquo;Site&rdquo;) and any purchase you make from Kun
          Foods (&ldquo;Kun Foods,&rdquo; &ldquo;we,&rdquo; &ldquo;us,&rdquo; or &ldquo;our&rdquo;). By accessing the Site
          or placing an order, you agree to be bound by these Terms. If you
          do not agree, please do not use the Site.
        </p>

        <h2>1. Eligibility</h2>
        <p>
          You must be at least 18 years old, or the age of majority in your
          jurisdiction, to place an order on the Site. By placing an order,
          you confirm that you meet this requirement and that the
          information you provide is accurate and complete.
        </p>

        <h2>2. Products and Pricing</h2>
        <p>
          We make reasonable efforts to display product descriptions,
          images, and prices accurately. However, we do not warrant that
          product descriptions, images, or other content are error-free.
          Prices are listed in Pakistani Rupees (PKR) and are subject to
          change without notice. Any promotional pricing is valid only for
          the period stated. In the event of a pricing error, we reserve
          the right to cancel any order placed at the incorrect price and
          will notify you and issue a full refund if payment has already
          been taken.
        </p>

        <h2>3. Orders and Acceptance</h2>
        <p>
          Placing an order on the Site constitutes an offer to purchase.
          All orders are subject to acceptance and availability. We reserve
          the right to refuse or cancel any order at our discretion,
          including in cases of suspected fraud, pricing errors, or
          product unavailability. If we cancel an order after payment has
          been taken, we will issue a full refund using the original
          payment method within a reasonable timeframe.
        </p>

        <h2>4. Payments</h2>
        <p>
          Payments are processed securely through our third-party payment
          gateway partner(s). By providing payment information, you
          represent that you are authorized to use the payment method
          provided. Card and bank details are handled directly by our
          payment gateway and are not stored on Kun Foods&rsquo; own servers
          (see our <a href="/privacy-policy">Privacy Policy</a> for
          details). We accept the payment methods displayed at checkout,
          which may include major debit/credit cards, mobile wallets, and
          cash on delivery where offered.
        </p>

        <h2>5. Shipping and Delivery</h2>
        <p>
          We aim to dispatch and deliver orders within the timeframes shown
          at checkout; these are estimates and not guaranteed delivery
          dates. Delivery times may vary due to courier delays, weather,
          public holidays, or circumstances beyond our reasonable control.
          Risk of loss and title to products pass to you upon delivery to
          the shipping address provided. Please ensure your delivery
          address and contact details are accurate — Kun Foods is not
          responsible for non-delivery caused by incorrect information
          supplied at checkout.
        </p>

        <h2>6. Returns, Refunds, and Cancellations</h2>
        <p>
          Because our products are consumable food items, we can only
          accept returns or offer refunds where:
        </p>
        <ul>
          <li>The product received is damaged, defective, expired, or materially different from what was ordered;</li>
          <li>The wrong product was delivered; or</li>
          <li>The order was cancelled or undelivered through no fault of the customer.</li>
        </ul>
        <p>
          To request a return or refund, contact us within 7 days of
          delivery at{" "}
          <a href="mailto:support@kunfoods.pk">support@kunfoods.pk</a> with
          your order number and, where applicable, photos of the issue. Once
          approved, refunds will be issued to your original payment method
          within a reasonable timeframe, or as store credit where agreed.
          For hygiene and safety reasons, we cannot accept returns of
          opened food products unless they are defective or incorrect.
        </p>

        <h2>7. Product Use and Allergen Information</h2>
        <p>
          Our products may be manufactured in facilities that also process
          common allergens (such as nuts, gluten-containing grains, or
          mustard). Please check product labels and descriptions carefully
          if you have any food allergies or sensitivities. Kun Foods is not
          liable for adverse reactions resulting from failure to review
          product or allergen information prior to use.
        </p>

        <h2>8. Account Responsibilities</h2>
        <p>
          If you create an account, you are responsible for maintaining the
          confidentiality of your login credentials and for all activity
          under your account. Notify us immediately of any unauthorized use
          of your account.
        </p>

        <h2>9. Intellectual Property</h2>
        <p>
          All content on the Site, including text, graphics, logos,
          product images, and the Kun Foods name and branding, is the
          property of Kun Foods or its licensors and is protected by
          applicable intellectual property laws. You may not reproduce,
          distribute, or create derivative works from any part of the Site
          without our prior written consent.
        </p>

        <h2>10. Prohibited Use</h2>
        <p>You agree not to use the Site to:</p>
        <ul>
          <li>Violate any applicable law or regulation;</li>
          <li>Submit false, fraudulent, or misleading information, including at checkout;</li>
          <li>Interfere with or disrupt the security or functioning of the Site;</li>
          <li>Attempt to gain unauthorized access to any part of the Site or its systems.</li>
        </ul>

        <h2>11. Limitation of Liability</h2>
        <p>
          To the fullest extent permitted by applicable law, Kun Foods
          shall not be liable for any indirect, incidental, special, or
          consequential damages arising out of or in connection with your
          use of the Site or our products. Our total liability for any
          claim arising from an order shall not exceed the amount you paid
          for that order. Nothing in these Terms limits any liability that
          cannot be excluded or limited under applicable law.
        </p>

        <h2>12. Changes to These Terms</h2>
        <p>
          We may update these Terms from time to time. Changes will be
          posted on this page with a revised &ldquo;Last updated&rdquo; date and take
          effect immediately upon posting. Your continued use of the Site
          after changes are posted constitutes acceptance of the updated
          Terms.
        </p>

        <h2>13. Governing Law</h2>
        <p>
          These Terms are governed by the laws of the Islamic Republic of
          Pakistan, without regard to conflict-of-law principles. Any
          disputes arising out of or relating to these Terms or the Site
          shall be subject to the exclusive jurisdiction of the courts of
          Lahore, Punjab, Pakistan.
        </p>

        <h2>14. Contact Us</h2>
        <p>
          Questions about these Terms can be directed to:
        </p>
        <p>
          Kun Foods
          <br />
          Email: <a href="mailto:support@kunfoods.pk">support@kunfoods.pk</a>
          <br />
          Phone: +92 42 1234 5678
          <br />
          Address: 123 Spice Market Road, Lahore, Punjab, Pakistan
        </p>
      </div>
    </div>
  );
}
