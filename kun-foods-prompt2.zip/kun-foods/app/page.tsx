"use client";

import { motion } from "framer-motion";
import { Flame, Leaf, Truck, ArrowRight, Sparkles } from "lucide-react";
import Button from "@/components/ui/Button";
import Card from "@/components/ui/Card";
import Badge from "@/components/ui/Badge";
import ProductCard from "@/components/product/ProductCard";
import ScrollReveal from "@/components/motion/ScrollReveal";
import { MOCK_PRODUCTS } from "@/lib/mock-data";

const heroContainer = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.12, delayChildren: 0.1 } },
};

const heroItem = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] } },
};

// Floating background icons for the hero — purely decorative, aria-hidden.
// Each has its own float speed/delay so they don't move in lockstep.
const FLOATERS = [
  { Icon: Flame, className: "left-[8%] top-[18%] h-8 w-8 text-chili/25", duration: 5, delay: 0 },
  { Icon: Sparkles, className: "left-[18%] top-[65%] h-6 w-6 text-turmeric/40", duration: 6, delay: 0.5 },
  { Icon: Flame, className: "right-[10%] top-[22%] h-10 w-10 text-saffron/25", duration: 7, delay: 1 },
  { Icon: Sparkles, className: "right-[16%] top-[68%] h-7 w-7 text-chili/20", duration: 5.5, delay: 1.5 },
  { Icon: Flame, className: "left-[45%] top-[10%] h-5 w-5 text-turmeric/30", duration: 6.5, delay: 0.8 },
];

const WHY_KUN_FOODS = [
  {
    title: "Farm Direct, Not Warehouse Direct",
    body: "We buy directly from growers in Punjab and Sindh at harvest, skipping the chain of middlemen that leaves most supermarket spice sitting in a warehouse for a year before it reaches you.",
  },
  {
    title: "Stone-Ground, On Purpose",
    body: "Fast steel milling generates heat, and heat cooks off the oils that carry flavor and aroma. We grind slower, in smaller batches, because it actually tastes like something.",
  },
  {
    title: "No Fillers, No Nonsense",
    body: "No starch, no artificial color, no 'spice blend (25%)' fine print. What's on the ingredient list is what's in the tin — nothing added to bulk out the weight.",
  },
];

export default function Home() {
  const featured = MOCK_PRODUCTS.slice(0, 4);

  return (
    <>
      {/* ================= HERO ================= */}
      <section className="spice-grain relative overflow-hidden px-4 pb-24 pt-16 sm:px-6 sm:pt-24 lg:px-8">
        <div className="pointer-events-none absolute inset-0" aria-hidden>
          {FLOATERS.map(({ Icon, className, duration, delay }, i) => (
            <motion.div
              key={i}
              className={`absolute ${className}`}
              animate={{ y: [0, -16, 0], rotate: [0, 8, 0] }}
              transition={{ duration, delay, repeat: Infinity, ease: "easeInOut" }}
            >
              <Icon className="h-full w-full" />
            </motion.div>
          ))}
        </div>

        <motion.div
          variants={heroContainer}
          initial="hidden"
          animate="visible"
          className="relative mx-auto max-w-4xl text-center"
        >
          <motion.div variants={heroItem}>
            <Badge variant="new" className="mb-5">
              Freshly Ground, Weekly
            </Badge>
          </motion.div>

          <motion.h1
            variants={heroItem}
            className="font-display text-4xl font-extrabold leading-[1.05] tracking-tight text-tandoor sm:text-6xl"
          >
            Spice is a story.
            <br />
            <span className="text-chili">We help you tell it.</span>
          </motion.h1>

          <motion.p
            variants={heroItem}
            className="mx-auto mt-6 max-w-xl text-base text-tandoor/70 sm:text-lg"
          >
            Kun Foods sources, roasts, and stone-grinds masalas straight from
            farms across Punjab and Sindh — delivered to your kitchen, still
            smelling like it was ground this morning. Because it was.
          </motion.p>

          <motion.div
            variants={heroItem}
            className="mt-8 flex flex-wrap items-center justify-center gap-4"
          >
            <Button href="/shop" size="lg">Shop the Range</Button>
            <Button href="/blog" size="lg" variant="outline">
              Read Our Story
            </Button>
          </motion.div>
        </motion.div>
      </section>

      {/* ================= TRUST STRIP ================= */}
      <section className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-3">
          {[
            { icon: Leaf, title: "Farm Direct", body: "Sourced straight from growers, no middlemen." },
            { icon: Flame, title: "Stone-Ground", body: "Slow-milled to protect flavor and aroma." },
            { icon: Truck, title: "Nationwide Delivery", body: "Fresh to your door, anywhere in Pakistan." },
          ].map(({ icon: Icon, title, body }, i) => (
            <ScrollReveal key={title} delay={i * 0.1}>
              <Card hoverLift={false} className="p-6">
                <Icon className="h-8 w-8 text-chili" />
                <h3 className="mt-4 font-display text-lg font-bold">{title}</h3>
                <p className="mt-1.5 text-sm text-tandoor/70">{body}</p>
              </Card>
            </ScrollReveal>
          ))}
        </div>
      </section>

      {/* ================= FEATURED PRODUCTS ================= */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <ScrollReveal className="mb-8 flex items-end justify-between">
          <div>
            <h2 className="font-display text-2xl font-bold sm:text-3xl">Bestsellers</h2>
            <p className="mt-1 text-sm text-tandoor/60">The blends people reorder the most.</p>
          </div>
          <Button href="/shop" variant="ghost" size="sm" className="gap-1.5">
            View all <ArrowRight className="h-4 w-4" />
          </Button>
        </ScrollReveal>
        <div className="grid grid-cols-2 gap-4 sm:gap-6 md:grid-cols-4">
          {featured.map((product, i) => (
            <ScrollReveal key={product.id} delay={i * 0.08}>
              <ProductCard product={product} priority={i < 2} />
            </ScrollReveal>
          ))}
        </div>
      </section>

      {/* ================= BRAND STORY ================= */}
      <section className="bg-tandoor px-4 py-20 text-cream sm:px-6 lg:px-8">
        <div className="mx-auto max-w-6xl">
          <ScrollReveal className="max-w-2xl">
            <p className="text-xs font-semibold uppercase tracking-widest text-turmeric">
              Why Kun Foods
            </p>
            <h2 className="mt-2 font-display text-3xl font-extrabold leading-tight sm:text-4xl">
              Your dadi&rsquo;s masala dabba, minus the guesswork.
            </h2>
            <p className="mt-4 text-cream/70">
              Every kitchen has that one aunt whose karahi just tastes
              different. Turns out it&rsquo;s rarely the recipe — it&rsquo;s the
              spice. We built Kun Foods to bottle that difference and ship
              it to you.
            </p>
          </ScrollReveal>

          <div className="mt-12 grid grid-cols-1 gap-8 sm:grid-cols-3">
            {WHY_KUN_FOODS.map((item, i) => (
              <ScrollReveal key={item.title} delay={i * 0.12} direction={i % 2 === 0 ? "left" : "right"}>
                <div className="border-t-2 border-chili pt-5">
                  <h3 className="font-display text-lg font-bold">{item.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-cream/60">{item.body}</p>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* ================= CLOSING CTA ================= */}
      <section className="px-4 py-20 sm:px-6 lg:px-8">
        <ScrollReveal className="mx-auto max-w-2xl text-center">
          <h2 className="font-display text-2xl font-bold sm:text-3xl">
            Ready to taste the difference?
          </h2>
          <p className="mx-auto mt-3 max-w-md text-tandoor/60">
            Six signature blends, stone-ground this week, ready to ship
            nationwide.
          </p>
          <Button href="/shop" size="lg" className="mt-6">Start Shopping</Button>
        </ScrollReveal>
      </section>
    </>
  );
}
