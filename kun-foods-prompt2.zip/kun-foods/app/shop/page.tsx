"use client";

import { useMemo, useState } from "react";
import { Search, PackageX } from "lucide-react";
import { MOCK_PRODUCTS, CATEGORIES } from "@/lib/mock-data";
import ProductCard from "@/components/product/ProductCard";
import ScrollReveal from "@/components/motion/ScrollReveal";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

export default function ShopPage() {
  const [query, setQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  const filtered = useMemo(() => {
    return MOCK_PRODUCTS.filter((p) => {
      const matchesCategory = !activeCategory || p.category === activeCategory;
      const matchesQuery =
        !query.trim() ||
        p.name.toLowerCase().includes(query.toLowerCase()) ||
        p.shortDescription.toLowerCase().includes(query.toLowerCase());
      return matchesCategory && matchesQuery;
    });
  }, [query, activeCategory]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <ScrollReveal>
        <h1 className="font-display text-3xl font-extrabold sm:text-4xl">Shop All Spices</h1>
        <p className="mt-2 max-w-xl text-tandoor/60">
          Every blend stone-ground in small batches. Filter by category or
          search for something specific.
        </p>
      </ScrollReveal>

      {/* Search + filters */}
      <ScrollReveal delay={0.05} className="mt-8">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="relative w-full sm:max-w-xs">
            <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-tandoor/40" />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search spices…"
              data-cursor-hover
              aria-label="Search products"
              className="w-full rounded-full border-2 border-tandoor/15 bg-white py-2.5 pl-11 pr-4 text-sm outline-none transition-colors focus:border-chili"
            />
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setActiveCategory(null)}
              data-cursor-hover
              className={cn(
                "rounded-full px-4 py-2 text-xs font-semibold uppercase tracking-wide transition-colors",
                activeCategory === null
                  ? "bg-chili text-cream"
                  : "bg-tandoor/5 text-tandoor/60 hover:bg-tandoor/10"
              )}
            >
              All
            </button>
            {CATEGORIES.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                data-cursor-hover
                className={cn(
                  "rounded-full px-4 py-2 text-xs font-semibold uppercase tracking-wide transition-colors",
                  activeCategory === category
                    ? "bg-chili text-cream"
                    : "bg-tandoor/5 text-tandoor/60 hover:bg-tandoor/10"
                )}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </ScrollReveal>

      {/* Grid / empty state */}
      {filtered.length > 0 ? (
        <motion.div
          layout
          className="mt-10 grid grid-cols-2 gap-4 sm:gap-6 md:grid-cols-3 lg:grid-cols-4"
        >
          {filtered.map((product, i) => (
            <ScrollReveal key={product.id} delay={Math.min(i, 4) * 0.05}>
              <ProductCard product={product} priority={i < 4} />
            </ScrollReveal>
          ))}
        </motion.div>
      ) : (
        <div className="mt-16 flex flex-col items-center gap-3 py-12 text-center">
          <PackageX className="h-10 w-10 text-tandoor/25" />
          <p className="font-display text-lg font-bold text-tandoor/70">No spices found</p>
          <p className="max-w-sm text-sm text-tandoor/50">
            Try a different search term, or clear the category filter — new
            blends are added regularly.
          </p>
        </div>
      )}
    </div>
  );
}
