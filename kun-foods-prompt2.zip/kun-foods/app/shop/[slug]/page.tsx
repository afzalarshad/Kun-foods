import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { MOCK_PRODUCTS, getProductBySlug, getRelatedProducts } from "@/lib/mock-data";
import ProductDetailClient from "@/components/product/ProductDetailClient";

interface ProductPageProps {
  params: { slug: string };
}

// Pre-render all 6 product pages at build time.
export function generateStaticParams() {
  return MOCK_PRODUCTS.map((p) => ({ slug: p.slug }));
}

export function generateMetadata({ params }: ProductPageProps): Metadata {
  const product = getProductBySlug(params.slug);
  if (!product) return { title: "Product Not Found | Kun Foods" };
  return {
    title: `${product.name} | Kun Foods`,
    description: product.shortDescription,
  };
}

export default function ProductPage({ params }: ProductPageProps) {
  const product = getProductBySlug(params.slug);
  if (!product) notFound();

  const relatedProducts = getRelatedProducts(product);

  return <ProductDetailClient product={product} relatedProducts={relatedProducts} />;
}
