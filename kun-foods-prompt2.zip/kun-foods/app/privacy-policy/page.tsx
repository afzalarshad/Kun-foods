import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Privacy Policy | Kun Foods",
};

export default function PrivacyPolicyPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-16 sm:px-6 lg:px-8">
      <h1 className="font-display text-3xl font-extrabold sm:text-4xl">Privacy Policy</h1>
      <p className="mt-2 text-sm text-tandoor/60">Last updated: August 2026</p>

      <div className="prose mt-8 max-w-none prose-headings:font-display prose-headings:font-bold prose-a:text-chili">
        <p>
          Kun Foods (&ldquo;Kun Foods,&rdquo; &ldquo;we,&rdquo; &ldquo;us,&rdquo; or &ldquo;our&rdquo;) respects your
          privacy and is committed to protecting the personal information
          you share with us when you visit kunfoods.pk or make a purchase
          from us (together, the &ldquo;Site&rdquo;). This Privacy Policy explains what
          information we collect, how we use it, who we share it with, and
          the choices and rights available to you.
        </p>
        <p>
          By using the Site, you agree to the collection and use of
          information in accordance with this policy. If you do not agree
          with our practices, please do not use the Site.
        </p>

        <h2>1. Information We Collect</h2>
        <p>We collect the following categories of information:</p>
        <ul>
          <li>
            <strong>Information you give us directly:</strong> name, email
            address, phone number, shipping and billing address, and any
            information you provide when you create an account, place an
            order, subscribe to our newsletter, or contact customer
            support.
          </li>
          <li>
            <strong>Order and transaction information:</strong> items
            purchased, order value, order history, delivery preferences,
            and communications related to your order.
          </li>
          <li>
            <strong>Payment information:</strong> when you make a payment,
            your card or bank details are collected and processed directly
            by our third-party payment gateway (see Section 4 below). We do
            not collect, see in full, or store your complete card number,
            CVV, or online banking credentials on our own servers.
          </li>
          <li>
            <strong>Technical and usage information:</strong> IP address,
            browser type, device type, pages viewed, referring URLs, and
            approximate location, collected automatically through cookies
            and similar technologies when you browse the Site.
          </li>
          <li>
            <strong>Communications:</strong> records of your correspondence
            with us, including customer support requests and reviews or
            feedback you submit.
          </li>
        </ul>

        <h2>2. How We Use Your Information</h2>
        <p>We use the information we collect to:</p>
        <ul>
          <li>Process, fulfil, and deliver your orders;</li>
          <li>Create and manage your account;</li>
          <li>Communicate with you about orders, deliveries, and customer support requests;</li>
          <li>Send you marketing communications, offers, and updates, where you have opted in, and which you can opt out of at any time;</li>
          <li>Improve, secure, and personalise the Site and our product offering;</li>
          <li>Detect, investigate, and prevent fraud, abuse, and security incidents;</li>
          <li>Comply with our legal and regulatory obligations, including tax and consumer-protection laws.</li>
        </ul>

        <h2>3. Cookies and Similar Technologies</h2>
        <p>
          We use cookies and similar technologies (such as local storage and
          pixels) to keep you signed in, remember items in your cart,
          understand how visitors use the Site, and measure the
          effectiveness of our marketing. Cookies we use fall into three
          broad categories:
        </p>
        <ul>
          <li>
            <strong>Essential cookies:</strong> required for core Site
            functionality, such as maintaining your cart and session. The
            Site may not work correctly without these.
          </li>
          <li>
            <strong>Analytics cookies:</strong> help us understand how the
            Site is used so we can improve it (for example, aggregated page
            views and traffic sources).
          </li>
          <li>
            <strong>Marketing cookies:</strong> used to show you relevant
            offers on and off the Site and to measure campaign performance.
          </li>
        </ul>
        <p>
          You can control or disable cookies through your browser settings
          at any time. Disabling essential cookies may affect the
          functionality of the Site, including your ability to complete a
          purchase.
        </p>

        <h2>4. Payment Data Handling</h2>
        <p>
          All card and bank-account details entered at checkout are
          transmitted directly to and processed by our licensed third-party
          payment gateway partner(s), not by Kun Foods. These providers are
          independently responsible for the security of the payment
          information they process and are required to comply with
          applicable card-network and financial-regulatory security
          standards (such as PCI-DSS). Kun Foods never stores your full
          card number, CVV, expiry date, or online banking password on our
          own systems. We retain only limited, non-sensitive transaction
          metadata (such as order total, payment status, and a masked
          reference to the payment method) needed for order records,
          accounting, and customer support.
        </p>

        <h2>5. How We Share Your Information</h2>
        <p>We do not sell your personal information. We share information only with:</p>
        <ul>
          <li>
            <strong>Service providers,</strong> such as payment gateways,
            courier and logistics partners, hosting and IT providers,
            email/SMS delivery services, and analytics providers, who
            process data on our behalf and under our instructions;
          </li>
          <li>
            <strong>Professional advisers and authorities,</strong> where
            required to comply with a legal obligation, court order, or
            valid governmental request, or to protect the rights, property,
            or safety of Kun Foods, our customers, or others;
          </li>
          <li>
            <strong>A successor entity,</strong> in the event of a merger,
            acquisition, restructuring, or sale of assets, subject to
            standard confidentiality arrangements.
          </li>
        </ul>

        <h2>6. Data Retention</h2>
        <p>
          We retain personal information for as long as necessary to
          fulfil the purposes described in this policy, including to
          provide our services, comply with our legal and tax obligations,
          resolve disputes, and enforce our agreements. Order records are
          typically retained for the period required under applicable tax
          and commercial law. When information is no longer needed, we
          delete or anonymise it.
        </p>

        <h2>7. Data Security</h2>
        <p>
          We use reasonable administrative, technical, and physical
          safeguards designed to protect your personal information from
          unauthorized access, disclosure, alteration, or destruction. No
          method of transmission or storage is completely secure, however,
          and we cannot guarantee absolute security.
        </p>

        <h2>8. Your Rights and Choices</h2>
        <p>You may, subject to applicable law:</p>
        <ul>
          <li>Request access to the personal information we hold about you;</li>
          <li>Request correction of inaccurate or incomplete information;</li>
          <li>Request deletion of your personal information, subject to our legal retention obligations;</li>
          <li>Withdraw consent to marketing communications at any time by using the &ldquo;unsubscribe&rdquo; link in our emails or contacting us directly;</li>
          <li>Ask us questions about how your information is processed.</li>
        </ul>
        <p>
          To exercise any of these rights, contact us using the details in
          Section 11. We will respond within a reasonable timeframe.
        </p>

        <h2>9. Children&rsquo;s Privacy</h2>
        <p>
          The Site is not directed at children under the age of 18, and we
          do not knowingly collect personal information from children. If
          you believe a child has provided us with personal information,
          please contact us so we can delete it.
        </p>

        <h2>10. Changes to This Policy</h2>
        <p>
          We may update this Privacy Policy from time to time to reflect
          changes in our practices or for legal, operational, or regulatory
          reasons. We will post the updated policy on this page with a
          revised &ldquo;Last updated&rdquo; date. We encourage you to review this
          page periodically.
        </p>

        <h2>11. Contact Us</h2>
        <p>
          If you have questions, concerns, or requests regarding this
          Privacy Policy or how we handle your personal information, please
          contact us at:
        </p>
        <p>
          Kun Foods
          <br />
          Email: <a href="mailto:privacy@kunfoods.pk">privacy@kunfoods.pk</a>
          <br />
          Phone: +92 42 1234 5678
          <br />
          Address: 123 Spice Market Road, Lahore, Punjab, Pakistan
        </p>
      </div>
    </div>
  );
}
