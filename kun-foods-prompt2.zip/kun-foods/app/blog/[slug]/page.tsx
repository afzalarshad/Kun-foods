import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { CalendarDays, Clock, ArrowLeft } from "lucide-react";
import { MOCK_BLOG_POSTS, getBlogPostBySlug } from "@/lib/mock-data";
import ProductImage from "@/components/product/ProductImage";

interface BlogPostPageProps {
  params: { slug: string };
}

export function generateStaticParams() {
  return MOCK_BLOG_POSTS.map((p) => ({ slug: p.slug }));
}

export function generateMetadata({ params }: BlogPostPageProps): Metadata {
  const post = getBlogPostBySlug(params.slug);
  if (!post) return { title: "Post Not Found | Kun Foods" };
  return { title: `${post.title} | Kun Foods Blog`, description: post.excerpt };
}

export default function BlogPostPage({ params }: BlogPostPageProps) {
  const post = getBlogPostBySlug(params.slug);
  if (!post) notFound();

  return (
    <article className="mx-auto max-w-2xl px-4 py-12 sm:px-6 lg:px-8">
      <Link
        href="/blog"
        data-cursor-hover
        className="inline-flex items-center gap-1.5 text-sm font-semibold text-tandoor/60 hover:text-chili"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to blog
      </Link>

      <p className="mt-6 text-xs font-semibold uppercase tracking-wide text-chili">
        {post.category}
      </p>
      <h1 className="mt-1 font-display text-3xl font-extrabold leading-tight sm:text-4xl">
        {post.title}
      </h1>

      <div className="mt-4 flex items-center gap-4 text-xs text-tandoor/50">
        <span>{post.author}</span>
        <span className="flex items-center gap-1.5">
          <CalendarDays className="h-3.5 w-3.5" />
          {new Date(post.date).toLocaleDateString("en-US", {
            month: "long",
            day: "numeric",
            year: "numeric",
          })}
        </span>
        <span className="flex items-center gap-1.5">
          <Clock className="h-3.5 w-3.5" />
          {post.readTime}
        </span>
      </div>

      <div className="relative mt-8 aspect-[16/9] overflow-hidden rounded-2xl bg-tandoor/5">
        <ProductImage src={post.coverImage} alt={post.title} priority sizes="(max-width: 768px) 100vw, 768px" />
      </div>

      <div className="prose mt-8 max-w-none prose-headings:font-display prose-a:text-chili">
        {post.content.map((paragraph, i) => (
          <p key={i}>{paragraph}</p>
        ))}
      </div>
    </article>
  );
}
