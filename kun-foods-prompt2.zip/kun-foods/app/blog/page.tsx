import type { Metadata } from "next";
import Link from "next/link";
import { CalendarDays, Clock } from "lucide-react";
import { MOCK_BLOG_POSTS } from "@/lib/mock-data";
import ProductImage from "@/components/product/ProductImage";
import ScrollReveal from "@/components/motion/ScrollReveal";

export const metadata: Metadata = {
  title: "Blog | Kun Foods",
  description: "Notes on spices, recipes, and how we make Kun Foods masalas.",
};

export default function BlogPage() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-12 sm:px-6 lg:px-8">
      <ScrollReveal>
        <h1 className="font-display text-3xl font-extrabold sm:text-4xl">From the Kitchen</h1>
        <p className="mt-2 max-w-xl text-tandoor/60">
          Recipes, spice know-how, and the occasional look behind the
          scenes at how we mill.
        </p>
      </ScrollReveal>

      <div className="mt-10 grid grid-cols-1 gap-8 sm:grid-cols-2">
        {MOCK_BLOG_POSTS.map((post, i) => (
          <ScrollReveal key={post.slug} delay={i * 0.08}>
            <Link href={`/blog/${post.slug}`} data-cursor-hover className="group block">
              <div className="relative aspect-[16/10] overflow-hidden rounded-2xl bg-tandoor/5">
                <ProductImage
                  src={post.coverImage}
                  alt={post.title}
                  className="transition-transform duration-500 group-hover:scale-105"
                  sizes="(max-width: 640px) 100vw, 50vw"
                />
              </div>
              <p className="mt-4 text-xs font-semibold uppercase tracking-wide text-chili">
                {post.category}
              </p>
              <h2 className="mt-1 font-display text-xl font-bold leading-snug group-hover:text-chili">
                {post.title}
              </h2>
              <p className="mt-2 text-sm text-tandoor/60">{post.excerpt}</p>
              <div className="mt-3 flex items-center gap-4 text-xs text-tandoor/50">
                <span className="flex items-center gap-1.5">
                  <CalendarDays className="h-3.5 w-3.5" />
                  {new Date(post.date).toLocaleDateString("en-US", {
                    month: "long",
                    day: "numeric",
                    year: "numeric",
                  })}
                </span>
                <span className="flex items-center gap-1.5">
                  <Clock className="h-3.5 w-3.5" />
                  {post.readTime}
                </span>
              </div>
            </Link>
          </ScrollReveal>
        ))}
      </div>
    </div>
  );
}
