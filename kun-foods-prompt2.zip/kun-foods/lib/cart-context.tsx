"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
  type RefObject,
} from "react";
import { AnimatePresence, motion } from "framer-motion";
import type { CartItem, Product } from "@/types";

const STORAGE_KEY = "kun-foods-cart";

interface FlyFrom {
  src: string;
  rect: DOMRect;
}

interface FlyingItem {
  id: string;
  src: string;
  startRect: DOMRect;
}

interface CartContextValue {
  items: CartItem[];
  itemCount: number;
  subtotal: number;
  isOpen: boolean;
  openCart: () => void;
  closeCart: () => void;
  addItem: (product: Product, quantity?: number, flyFrom?: FlyFrom) => void;
  removeItem: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  /** Attach to the Navbar's cart button so add-to-cart animations know where to fly to. */
  cartIconRef: RefObject<HTMLButtonElement>;
  /** Increments every time an item lands in the cart — Navbar watches this to pulse the icon. */
  bumpKey: number;
}

const CartContext = createContext<CartContextValue | null>(null);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [hydrated, setHydrated] = useState(false);
  const [flying, setFlying] = useState<FlyingItem[]>([]);
  const [bumpKey, setBumpKey] = useState(0);
  const cartIconRef = useRef<HTMLButtonElement>(null);

  // Load persisted cart once on mount (client-only — localStorage isn't
  // available during SSR).
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setItems(JSON.parse(raw));
    } catch {
      // corrupted or inaccessible storage — start with an empty cart
    }
    setHydrated(true);
  }, []);

  // Persist on every change, but only after the initial load above has
  // happened, so we don't immediately overwrite storage with an empty array.
  useEffect(() => {
    if (!hydrated) return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    } catch {
      // storage full or unavailable (e.g. private browsing) — fail silently
    }
  }, [items, hydrated]);

  const addItem = useCallback((product: Product, quantity = 1, flyFrom?: FlyFrom) => {
    setItems((prev) => {
      const existing = prev.find((i) => i.product.id === product.id);
      if (existing) {
        return prev.map((i) =>
          i.product.id === product.id ? { ...i, quantity: i.quantity + quantity } : i
        );
      }
      return [...prev, { product, quantity }];
    });

    if (flyFrom) {
      const id = crypto.randomUUID();
      setFlying((prev) => [...prev, { id, src: flyFrom.src, startRect: flyFrom.rect }]);
    } else {
      setBumpKey((k) => k + 1);
    }
  }, []);

  const removeItem = useCallback((productId: string) => {
    setItems((prev) => prev.filter((i) => i.product.id !== productId));
  }, []);

  const updateQuantity = useCallback((productId: string, quantity: number) => {
    setItems((prev) =>
      quantity <= 0
        ? prev.filter((i) => i.product.id !== productId)
        : prev.map((i) => (i.product.id === productId ? { ...i, quantity } : i))
    );
  }, []);

  const removeFlying = useCallback((id: string) => {
    setFlying((prev) => prev.filter((f) => f.id !== id));
  }, []);

  const itemCount = items.reduce((sum, i) => sum + i.quantity, 0);
  const subtotal = items.reduce((sum, i) => sum + i.product.price * i.quantity, 0);

  return (
    <CartContext.Provider
      value={{
        items,
        itemCount,
        subtotal,
        isOpen,
        openCart: () => setIsOpen(true),
        closeCart: () => setIsOpen(false),
        addItem,
        removeItem,
        updateQuantity,
        cartIconRef,
        bumpKey,
      }}
    >
      {children}

      {/* "Fly to cart" overlay — a cloned product thumbnail animates from the
          Add to Cart button to the navbar cart icon, then fades. Purely
          decorative; the actual cart state updates instantly in addItem
          above, this just gives the click a satisfying payoff. */}
      <AnimatePresence>
        {flying.map((f) => {
          const targetRect = cartIconRef.current?.getBoundingClientRect();
          if (!targetRect) return null;
          const SIZE = 56;
          return (
            <motion.div
              key={f.id}
              aria-hidden
              className="pointer-events-none fixed z-[300] rounded-full border-2 border-chili bg-cover bg-center shadow-spice"
              style={{
                width: SIZE,
                height: SIZE,
                backgroundImage: `url(${f.src})`,
              }}
              initial={{
                left: f.startRect.left + f.startRect.width / 2 - SIZE / 2,
                top: f.startRect.top + f.startRect.height / 2 - SIZE / 2,
                opacity: 1,
                scale: 1,
              }}
              animate={{
                left: targetRect.left + targetRect.width / 2 - SIZE / 2,
                top: targetRect.top + targetRect.height / 2 - SIZE / 2,
                opacity: 0.15,
                scale: 0.25,
              }}
              transition={{ duration: 0.7, ease: [0.4, 0, 0.6, 1] }}
              onAnimationComplete={() => {
                removeFlying(f.id);
                setBumpKey((k) => k + 1);
              }}
            />
          );
        })}
      </AnimatePresence>
    </CartContext.Provider>
  );
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within a CartProvider");
  return ctx;
}
