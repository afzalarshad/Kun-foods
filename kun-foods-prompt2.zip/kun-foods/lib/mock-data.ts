import type { Product, BlogPost } from "@/types";

/* ============================================================================
 * PRODUCT IMAGES — PLACEHOLDER SOURCE
 * ----------------------------------------------------------------------------
 * Every `images` array below points at Unsplash placeholder photography
 * (food/spice-themed) so the shop looks real during development. Each URL
 * is commented with what it's standing in for. To swap in your own product
 * photography later:
 *   1. Drop real photos in /public/products/<slug>/1.jpg, 2.jpg, ...
 *   2. Replace the matching `images: [...]` array below with those paths,
 *      e.g. images: ["/products/garam-masala/1.jpg", "/products/garam-masala/2.jpg"]
 * No other code needs to change — ProductImage (components/product/
 * ProductImage.tsx) and the gallery on the PDP both just map over this array,
 * and already fall back to a branded placeholder if any URL fails to load.
 * ==========================================================================*/
export const MOCK_PRODUCTS: Product[] = [
  {
    id: "1",
    slug: "garam-masala",
    name: "Classic Garam Masala",
    shortDescription: "A warm, aromatic house blend — 12 whole spices, stone-ground.",
    description:
      "Our signature Garam Masala is built the way it's been done in Punjabi kitchens for generations: whole cinnamon, cloves, cardamom, black pepper, bay leaf, and eight more spices, dry-roasted in small batches to wake up their oils, then stone-ground the same day. Add a pinch at the end of cooking — not the start — and watch it bloom.",
    price: 380,
    weight: "100g",
    images: [
      // Unsplash — jars/bowls of mixed ground spices
      "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=1000&q=80",
      // Unsplash — close-up spice texture
      "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=1000&q=60&sat=-20",
    ],
    category: "Blends",
    spiceLevel: "medium",
    isNew: true,
    inStock: true,
    rating: 4.9,
    reviewCount: 187,
    ingredients: ["Cinnamon", "Cloves", "Green cardamom", "Black cardamom", "Black pepper", "Bay leaf", "Cumin", "Coriander", "Star anise", "Mace", "Nutmeg", "Fennel"],
    usageTips: "Stir in during the last 2–3 minutes of cooking for maximum aroma, or dust over finished curries and grilled meat.",
  },
  {
    id: "2",
    slug: "chaat-masala",
    name: "Tangy Chaat Masala",
    shortDescription: "The sharp, tangy finisher for fruit, snacks, and street food.",
    description:
      "Sour, salty, and just a little funky — our Chaat Masala is built around sun-dried black salt and amchoor (dried mango powder) for that unmistakable street-food tang. Sprinkle it over fruit chaat, samosas, fries, or a squeeze of lemon and soda for an instant jal-jeera.",
    price: 340,
    weight: "100g",
    images: [
      // Unsplash — spice powder in small bowl, overhead shot
      "https://images.unsplash.com/photo-1599909533144-9c3f6cd47f3d?auto=format&fit=crop&w=1000&q=80",
    ],
    category: "Blends",
    spiceLevel: "mild",
    inStock: true,
    rating: 4.7,
    reviewCount: 132,
    ingredients: ["Black salt", "Amchoor (dried mango)", "Cumin", "Coriander", "Black pepper", "Asafoetida", "Ginger powder", "Mint"],
    usageTips: "Best added right before serving — heat dulls the tang. Try it on popcorn.",
  },
  {
    id: "3",
    slug: "biryani-masala",
    name: "Signature Biryani Masala",
    shortDescription: "Our best-seller. One tin, restaurant-grade biryani.",
    description:
      "Years of tweaking went into this one. It's a layered blend — whole spices for the rice, ground spices for the masala, dried rose petals for fragrance — built to give home cooks the depth that usually takes a professional dum kitchen to pull off. Works for chicken, beef, or vegetable biryani alike.",
    price: 490,
    compareAtPrice: 560,
    weight: "150g",
    images: [
      // Unsplash — cooked biryani / rice dish with garnish
      "https://images.unsplash.com/photo-1563379091339-03246963d96c?auto=format&fit=crop&w=1000&q=80",
      // Unsplash — assorted whole spices flat lay
      "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=1000&q=80&sat=10",
    ],
    category: "Blends",
    spiceLevel: "medium",
    isNew: true,
    inStock: true,
    rating: 5,
    reviewCount: 441,
    ingredients: ["Basmati-grade whole spices", "Dried rose petals", "Mace", "Star anise", "Shahi jeera", "Kashmiri chili", "Bay leaf"],
    usageTips: "Layer half the masala with the meat marinade and half between rice layers before dum-cooking.",
  },
  {
    id: "4",
    slug: "karahi-masala",
    name: "Karahi Masala",
    shortDescription: "Sharp, tomato-forward blend built for a sizzling wok.",
    description:
      "Made for high-heat, fast cooking. This blend leans into whole coriander seed and green chili so it holds its own against a hot karahi, fresh tomatoes, and ginger-garlic — the base of every good karahi gosht. One tablespoon per 500g of meat is the ratio we use in our own test kitchen.",
    price: 410,
    weight: "125g",
    images: [
      // Unsplash — karahi/wok style curry dish
      "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=1000&q=80",
    ],
    category: "Blends",
    spiceLevel: "hot",
    inStock: true,
    rating: 4.8,
    reviewCount: 156,
    ingredients: ["Coriander seed", "Cumin", "Dried green chili", "Kashmiri chili", "Black pepper", "Ajwain", "Ginger powder"],
    usageTips: "Toast briefly in the oil before adding tomatoes to deepen the flavor.",
  },
  {
    id: "5",
    slug: "tikka-masala",
    name: "Tikka Masala",
    shortDescription: "Smoky, yogurt-marinade-ready blend for grilled and baked tikka.",
    description:
      "Balanced for a yogurt marinade — smoky paprika and Kashmiri chili for color and warmth, not scorching heat, plus a touch of dried fenugreek leaf for that char-grilled restaurant aroma. Works equally well under the broiler, on a tawa, or over charcoal.",
    price: 400,
    weight: "125g",
    images: [
      // Unsplash — grilled/skewered meat (tikka style)
      "https://images.unsplash.com/photo-1600628421066-f6bda6a7b976?auto=format&fit=crop&w=1000&q=80",
    ],
    category: "Blends",
    spiceLevel: "medium",
    inStock: true,
    rating: 4.6,
    reviewCount: 98,
    ingredients: ["Kashmiri chili", "Smoked paprika", "Dried fenugreek leaf", "Garlic powder", "Ginger powder", "Garam masala", "Yogurt powder"],
    usageTips: "Mix with plain yogurt and marinate at least 2 hours, ideally overnight, before grilling.",
  },
  {
    id: "6",
    slug: "chai-masala",
    name: "Chai Masala",
    shortDescription: "A warming spice blend for the perfect cup of doodh patti.",
    description:
      "Cardamom-forward with a warm backbone of ginger, cinnamon, and clove — this is the blend behind a proper roadside cup of chai. A quarter teaspoon simmered with milk, water, and black tea leaves for five minutes is all it takes.",
    price: 350,
    weight: "80g",
    images: [
      // Unsplash — chai/tea with spices
      "https://images.unsplash.com/photo-1571934811356-5cc061b6821f?auto=format&fit=crop&w=1000&q=80",
    ],
    category: "Beverage Blends",
    spiceLevel: "mild",
    inStock: false,
    rating: 4.9,
    reviewCount: 210,
    ingredients: ["Green cardamom", "Ginger", "Cinnamon", "Cloves", "Black pepper", "Fennel seed"],
    usageTips: "Simmer, don't boil hard — long gentle heat pulls more flavor from the spices without turning bitter.",
  },
];

export const CATEGORIES = Array.from(new Set(MOCK_PRODUCTS.map((p) => p.category)));

export function getProductBySlug(slug: string) {
  return MOCK_PRODUCTS.find((p) => p.slug === slug);
}

export function getRelatedProducts(product: Product, count = 4) {
  return MOCK_PRODUCTS.filter(
    (p) => p.id !== product.id && p.category === product.category
  )
    .concat(MOCK_PRODUCTS.filter((p) => p.id !== product.id && p.category !== product.category))
    .slice(0, count);
}

export const NAV_LINKS = [
  { label: "Home", href: "/" },
  { label: "Shop", href: "/shop" },
  { label: "Blog", href: "/blog" },
  { label: "About", href: "/about" },
  { label: "Contact", href: "/contact" },
];

/* ============================================================================
 * BLOG — PLACEHOLDER POSTS
 * ==========================================================================*/
export const MOCK_BLOG_POSTS: BlogPost[] = [
  {
    slug: "five-spices-every-pakistani-kitchen-needs",
    title: "5 Spices Every Pakistani Kitchen Needs (And 2 You Can Skip)",
    excerpt:
      "You don't need forty jars on your spice rack. Here's the short list that actually earns its shelf space.",
    coverImage:
      // Unsplash — spice rack / jars
      "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=1200&q=80",
    author: "Kun Foods Kitchen",
    date: "2026-06-02",
    readTime: "4 min read",
    category: "Guides",
    content: [
      "Walk into most Pakistani kitchens and you'll find a spice rack that's grown organically over decades — a jar for every dish anyone in the family has ever cooked once. Most of it goes stale before it's used twice.",
      "If you're starting from scratch, or trying to declutter, five blends will get you through 90% of home cooking: garam masala, red chili powder, turmeric, cumin, and coriander. Everything else — chaat masala, biryani masala, tikka masala — is a specialist tool for a specific dish.",
      "The two you can skip, unless you cook a specific regional dish often: panch phoron (unless you're making Bengali-style dal regularly) and kewra water (lovely in biryani, but a single small bottle lasts years).",
      "The bigger lesson is freshness over collection size. A small rack of spices bought in the last six months will outperform a large rack bought over six years, every time.",
    ],
  },
  {
    slug: "why-stone-ground-matters",
    title: "Why Stone-Ground Actually Matters (It's Not Just Marketing)",
    excerpt:
      "The difference between stone-ground and machine-milled spice isn't romantic nostalgia — it's heat, and heat kills flavor.",
    coverImage:
      // Unsplash — traditional grinding stone / mortar and pestle
      "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=1200&q=60&sat=-10",
    author: "Kun Foods Kitchen",
    date: "2026-05-14",
    readTime: "3 min read",
    category: "Behind the Scenes",
    content: [
      "High-speed steel milling generates friction, and friction generates heat. That heat cooks off the volatile oils in a spice — the exact compounds responsible for aroma — before the powder even reaches the jar.",
      "Traditional stone grinding (chakki milling) runs slower and cooler by design. It takes longer and produces less per hour, which is exactly why most large manufacturers moved away from it.",
      "In practice, this is why a stone-ground garam masala smells noticeably stronger straight out of the packet than a supermarket equivalent, even if the ingredient list looks identical on paper.",
      "We mill in small batches for this reason. It costs more and takes longer. We think it's worth it.",
    ],
  },
  {
    slug: "weeknight-karahi-in-25-minutes",
    title: "Weeknight Chicken Karahi in 25 Minutes",
    excerpt:
      "A stripped-down, no-fuss version of the classic — built for a Tuesday, not a dinner party.",
    coverImage:
      // Unsplash — karahi/curry cooking in a wok
      "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=1200&q=80",
    author: "Kun Foods Kitchen",
    date: "2026-04-22",
    readTime: "5 min read",
    category: "Recipes",
    content: [
      "Real karahi gosht takes a slow hand and a lot of tomatoes. This is the version we actually make on a Tuesday: fewer steps, same flavor direction, on the table in under half an hour.",
      "Start with boneless chicken thigh, cut small so it cooks fast. High heat, a splash of oil, and don't crowd the pan — you want char, not steam.",
      "Add ginger-garlic paste and green chilies, then two tablespoons of our Karahi Masala straight in with the chicken rather than blooming it separately — it's built to hold up to direct heat.",
      "Crushed tomatoes go in once the chicken's sealed, then a lid on for eight minutes. Finish with julienned ginger and coriander. Naan or plain rice, your call.",
    ],
  },
];

export function getBlogPostBySlug(slug: string) {
  return MOCK_BLOG_POSTS.find((p) => p.slug === slug);
}
