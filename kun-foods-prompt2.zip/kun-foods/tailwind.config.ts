import type { Config } from "tailwindcss";

// Colors are read from CSS variables (set in app/globals.css) rather than
// hard-coded here. This means a future admin settings table can update
// --color-chili / --color-turmeric / etc at runtime (e.g. by writing new
// values onto :root via JS) and every component using these Tailwind
// classes (bg-chili, text-turmeric, etc) will update without a rebuild.
const withOpacity = (variable: string) => {
  return `rgb(var(${variable}) / <alpha-value>)`;
};

const config: Config = {
  darkMode: "class",
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./lib/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        chili: withOpacity("--color-chili"),
        turmeric: withOpacity("--color-turmeric"),
        saffron: withOpacity("--color-saffron"),
        masala: withOpacity("--color-masala"),
        cream: withOpacity("--color-cream"),
        tandoor: withOpacity("--color-tandoor"),
      },
      fontFamily: {
        display: ["var(--font-display)", "sans-serif"],
        body: ["var(--font-body)", "sans-serif"],
      },
      borderRadius: {
        xl: "1rem",
        "2xl": "1.5rem",
        "3xl": "2rem",
      },
      boxShadow: {
        spice: "0 8px 30px -8px rgb(var(--color-chili) / 0.35)",
        "spice-lg": "0 20px 50px -12px rgb(var(--color-tandoor) / 0.25)",
      },
      keyframes: {
        "toast-in": {
          "0%": { transform: "translateY(100%)", opacity: "0" },
          "100%": { transform: "translateY(0)", opacity: "1" },
        },
        sizzle: {
          "0%, 100%": { transform: "scale(1)" },
          "50%": { transform: "scale(1.04)" },
        },
      },
      animation: {
        sizzle: "sizzle 2.5s ease-in-out infinite",
      },
    },
  },
  plugins: [require("@tailwindcss/typography")],
};

export default config;
