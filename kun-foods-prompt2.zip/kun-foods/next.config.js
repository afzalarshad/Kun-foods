/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    remotePatterns: [
      // Unsplash — used for placeholder product/blog photography. Swap
      // MOCK_PRODUCTS / MOCK_BLOG_POSTS in lib/mock-data.ts for real
      // uploads under /public and this entry can be removed.
      { protocol: 'https', hostname: 'images.unsplash.com' },
    ]
  }
};

module.exports = nextConfig;
