"use client";

import { useEffect, useRef, useState } from "react";

/**
 * Replaces the system cursor with a small chili-pepper icon on fine-pointer
 * devices (mouse/trackpad). Design choice: a chili is the single most
 * recognizable icon for a spice brand, and stays legible at 22px.
 *
 * Perf notes:
 * - Position is written directly to a ref's style.transform on every
 *   mousemove, NOT through React state — avoids a re-render per pixel of
 *   mouse movement, which is what causes custom cursors to feel laggy.
 * - Hover scale-up uses event delegation on `mouseover` (checking
 *   closest("[data-cursor-hover], a, button")) instead of attaching a
 *   listener to every interactive element.
 * - Detects touch devices via matchMedia('(pointer: coarse)') once on
 *   mount and bails out entirely (renders nothing, adds no listeners,
 *   never sets cursor:none) so mobile/tablet is untouched.
 */
export default function CustomCursor() {
  const dotRef = useRef<HTMLDivElement>(null);
  const [enabled, setEnabled] = useState(false);
  const [isHoveringInteractive, setIsHoveringInteractive] = useState(false);

  useEffect(() => {
    const isCoarsePointer = window.matchMedia("(pointer: coarse)").matches;
    const hasNoHover = window.matchMedia("(hover: none)").matches;
    if (isCoarsePointer || hasNoHover) return; // touch/tablet: do nothing

    setEnabled(true);
    document.body.classList.add("custom-cursor-active");

    let rafId: number;
    let targetX = window.innerWidth / 2;
    let targetY = window.innerHeight / 2;

    const handleMove = (e: MouseEvent) => {
      targetX = e.clientX;
      targetY = e.clientY;
    };

    const render = () => {
      if (dotRef.current) {
        dotRef.current.style.transform = `translate3d(${targetX}px, ${targetY}px, 0) translate(-50%, -50%)`;
      }
      rafId = requestAnimationFrame(render);
    };
    rafId = requestAnimationFrame(render);

    const handleOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      setIsHoveringInteractive(!!target.closest("a, button, [data-cursor-hover], input, textarea, select"));
    };

    window.addEventListener("mousemove", handleMove, { passive: true });
    window.addEventListener("mouseover", handleOver, { passive: true });

    return () => {
      cancelAnimationFrame(rafId);
      window.removeEventListener("mousemove", handleMove);
      window.removeEventListener("mouseover", handleOver);
      document.body.classList.remove("custom-cursor-active");
    };
  }, []);

  if (!enabled) return null;

  return (
    <div
      ref={dotRef}
      aria-hidden
      className="pointer-events-none fixed left-0 top-0 z-[9999] will-change-transform transition-[scale] duration-150 ease-out"
      style={{ scale: isHoveringInteractive ? 1.5 : 1 }}
    >
      <svg
        width="26"
        height="26"
        viewBox="0 0 26 26"
        fill="none"
        style={{ transform: "rotate(-25deg)" }}
      >
        <path
          d="M9 4C8 6 7.5 8 9 9.5C7 9.8 5.2 11.3 5 14C4.7 18 8 21.5 12 21.5C16.5 21.5 19.5 17.8 19 13.5C18.6 10 16 8 14 8"
          stroke="rgb(var(--color-chili))"
          strokeWidth="2.4"
          strokeLinecap="round"
          strokeLinejoin="round"
          fill="rgb(var(--color-chili) / 0.9)"
        />
        <path
          d="M9 4C9.5 3 10.8 2.2 12 2.5"
          stroke="rgb(var(--color-masala))"
          strokeWidth="2.2"
          strokeLinecap="round"
        />
      </svg>
    </div>
  );
}
