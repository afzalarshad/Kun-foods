import Link from "next/link";
import { Facebook, Instagram, Twitter, Youtube, Mail, Phone, MapPin } from "lucide-react";
import Logo from "./Logo";
import { NAV_LINKS } from "@/lib/mock-data";

const SOCIAL_LINKS = [
  { label: "Facebook", href: "https://facebook.com", icon: Facebook },
  { label: "Instagram", href: "https://instagram.com", icon: Instagram },
  { label: "Twitter", href: "https://twitter.com", icon: Twitter },
  { label: "YouTube", href: "https://youtube.com", icon: Youtube },
];

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-tandoor/10 bg-white/50">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-10 sm:grid-cols-2 lg:grid-cols-4">
          {/* Brand */}
          <div className="lg:col-span-1">
            <Logo heightClass="h-9" />
            <p className="mt-4 text-sm leading-relaxed text-tandoor/70">
              Kun Foods brings you stone-ground masalas and spices sourced
              directly from farms across Pakistan — no fillers, no shortcuts,
              just the real thing.
            </p>
            <div className="mt-5 flex gap-2">
              {SOCIAL_LINKS.map(({ label, href, icon: Icon }) => (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  data-cursor-hover
                  aria-label={label}
                  className="flex h-9 w-9 items-center justify-center rounded-full bg-tandoor/5 text-tandoor/70 transition-colors hover:bg-chili hover:text-cream"
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick links */}
          <div>
            <h3 className="font-display text-sm font-bold uppercase tracking-wide text-tandoor">
              Quick Links
            </h3>
            <ul className="mt-4 space-y-2.5">
              {NAV_LINKS.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    data-cursor-hover
                    className="text-sm text-tandoor/70 hover:text-chili"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-display text-sm font-bold uppercase tracking-wide text-tandoor">
              Contact
            </h3>
            <ul className="mt-4 space-y-3">
              <li className="flex items-start gap-2.5 text-sm text-tandoor/70">
                <Mail className="mt-0.5 h-4 w-4 shrink-0 text-chili" />
                <a href="mailto:hello@kunfoods.pk" data-cursor-hover className="hover:text-chili">
                  hello@kunfoods.pk
                </a>
              </li>
              <li className="flex items-start gap-2.5 text-sm text-tandoor/70">
                <Phone className="mt-0.5 h-4 w-4 shrink-0 text-chili" />
                <a href="tel:+924212345678" data-cursor-hover className="hover:text-chili">
                  +92 42 1234 5678
                </a>
              </li>
              <li className="flex items-start gap-2.5 text-sm text-tandoor/70">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-chili" />
                <span>123 Spice Market Road, Lahore, Punjab, Pakistan</span>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="font-display text-sm font-bold uppercase tracking-wide text-tandoor">
              Legal
            </h3>
            <ul className="mt-4 space-y-2.5">
              <li>
                <Link href="/privacy-policy" data-cursor-hover className="text-sm text-tandoor/70 hover:text-chili">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/terms" data-cursor-hover className="text-sm text-tandoor/70 hover:text-chili">
                  Terms &amp; Conditions
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-10 border-t border-tandoor/10 pt-6 text-center text-xs text-tandoor/50">
          © {year} Kun Foods. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
