import Link from "next/link";
import { cn } from "@/lib/utils";

interface LogoProps {
  className?: string;
  heightClass?: string; // Tailwind height utility, e.g. "h-10"
}

/**
 * Renders /public/logo.png. Deliberately uses a plain <img> rather than
 * next/image's `fill` mode: a fixed height class + `w-auto` lets the
 * browser compute width from the file's real intrinsic aspect ratio, so
 * whatever the final logo turns out to be (square mark, wide wordmark,
 * tall emblem...) it scales correctly with no stretching or cropping and
 * no code changes needed when you drop in the real file.
 */
export default function Logo({ className, heightClass = "h-10" }: LogoProps) {
  return (
    <Link
      href="/"
      data-cursor-hover
      className={cn("inline-flex shrink-0 items-center", className)}
      aria-label="Kun Foods — home"
    >
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src="/logo.png"
        alt="Kun Foods"
        className={cn(heightClass, "w-auto max-w-[180px] object-contain")}
      />
    </Link>
  );
}
