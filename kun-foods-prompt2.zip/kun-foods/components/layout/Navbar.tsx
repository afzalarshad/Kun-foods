"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { AnimatePresence, motion, useAnimationControls } from "framer-motion";
import { Menu, X, ShoppingBag } from "lucide-react";
import Logo from "./Logo";
import { NAV_LINKS } from "@/lib/mock-data";
import { cn } from "@/lib/utils";
import { useCart } from "@/lib/cart-context";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const pathname = usePathname();
  const { itemCount, isOpen, openCart, closeCart, cartIconRef, bumpKey } = useCart();
  const cartControls = useAnimationControls();

  // Pulse the cart icon whenever an item lands (either via the fly-to-cart
  // animation completing, or a direct add with no animation to wait on).
  useEffect(() => {
    if (bumpKey === 0) return;
    cartControls.start({
      scale: [1, 1.3, 1],
      transition: { duration: 0.35 },
    });
  }, [bumpKey, cartControls]);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // close the mobile menu on route change
  useEffect(() => setMenuOpen(false), [pathname]);

  return (
    <header
      className={cn(
        "sticky top-0 z-50 w-full transition-all duration-300",
        scrolled
          ? "bg-cream/90 shadow-sm backdrop-blur-md"
          : "bg-cream/0"
      )}
    >
      <nav
        className={cn(
          "mx-auto flex max-w-7xl items-center justify-between px-4 transition-all duration-300 sm:px-6 lg:px-8",
          scrolled ? "py-3" : "py-5"
        )}
        aria-label="Main navigation"
      >
        <Logo />

        {/* Desktop links */}
        <ul className="hidden items-center gap-8 md:flex">
          {NAV_LINKS.map((link) => (
            <li key={link.href}>
              <Link
                href={link.href}
                data-cursor-hover
                className={cn(
                  "font-display text-sm font-semibold tracking-wide text-tandoor/80 transition-colors hover:text-chili",
                  pathname === link.href && "text-chili"
                )}
              >
                {link.label}
              </Link>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-2">
          <motion.button
            ref={cartIconRef}
            animate={cartControls}
            data-cursor-hover
            aria-label={`View cart, ${itemCount} item${itemCount === 1 ? "" : "s"}`}
            onClick={() => (isOpen ? closeCart() : openCart())}
            className="relative inline-flex rounded-full p-2.5 text-tandoor hover:bg-tandoor/5"
          >
            <ShoppingBag className="h-5 w-5" />
            {itemCount > 0 && (
              <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-chili px-1 text-[10px] font-bold text-cream">
                {itemCount}
              </span>
            )}
          </motion.button>

          {/* Mobile hamburger */}
          <button
            data-cursor-hover
            aria-label={menuOpen ? "Close menu" : "Open menu"}
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((v) => !v)}
            className="rounded-full p-2.5 text-tandoor hover:bg-tandoor/5 md:hidden"
          >
            {menuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </nav>

      {/* Mobile slide-in panel */}
      <AnimatePresence>
        {menuOpen && (
          <>
            <motion.div
              className="fixed inset-0 top-0 z-40 bg-tandoor/40 md:hidden"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setMenuOpen(false)}
              aria-hidden
            />
            <motion.div
              className="fixed right-0 top-0 z-40 h-full w-[78%] max-w-xs bg-cream p-6 pt-24 shadow-spice-lg md:hidden"
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", stiffness: 300, damping: 32 }}
            >
              <ul className="flex flex-col gap-1">
                {NAV_LINKS.map((link, i) => (
                  <motion.li
                    key={link.href}
                    initial={{ opacity: 0, x: 24 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.05 * i + 0.1 }}
                  >
                    <Link
                      href={link.href}
                      data-cursor-hover
                      className={cn(
                        "block rounded-xl px-4 py-3 font-display text-lg font-semibold text-tandoor/80 hover:bg-chili/10 hover:text-chili",
                        pathname === link.href && "bg-chili/10 text-chili"
                      )}
                    >
                      {link.label}
                    </Link>
                  </motion.li>
                ))}
              </ul>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </header>
  );
}
