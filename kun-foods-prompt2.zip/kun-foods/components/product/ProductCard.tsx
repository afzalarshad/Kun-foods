"use client";

import { useRef } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { Plus, Star } from "lucide-react";
import type { Product } from "@/types";
import ProductImage from "./ProductImage";
import Badge from "@/components/ui/Badge";
import { useCart } from "@/lib/cart-context";
import { useToast } from "@/components/ui/Toast";
import { formatPKR, cn } from "@/lib/utils";

interface ProductCardProps {
  product: Product;
  priority?: boolean;
}

/**
 * Shared product card used on the home page, /shop grid, and related
 * products. Hover state does three things at once — slight lift, a soft
 * tilt toward the cursor's quadrant is intentionally skipped in favour of
 * a simpler scale+shadow (a true 3D tilt reads as gimmicky on a dense
 * product grid) — and the quick-add button triggers the fly-to-cart
 * animation from its own position.
 */
export default function ProductCard({ product, priority }: ProductCardProps) {
  const addButtonRef = useRef<HTMLButtonElement>(null);
  const { addItem } = useCart();
  const { showToast } = useToast();

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const rect = addButtonRef.current?.getBoundingClientRect();
    addItem(product, 1, rect ? { src: product.images[0], rect } : undefined);
    showToast({ title: "Added to cart", description: product.name, variant: "success" });
  };

  return (
    <motion.div
      whileHover={{ y: -6, scale: 1.015 }}
      transition={{ type: "spring", stiffness: 300, damping: 22 }}
      className="group"
    >
      <Link
        href={`/shop/${product.slug}`}
        data-cursor-hover
        className="block overflow-hidden rounded-2xl border border-tandoor/10 bg-white/70 shadow-sm transition-shadow duration-300 group-hover:shadow-spice-lg"
      >
        <div className="relative aspect-square overflow-hidden bg-tandoor/5">
          <ProductImage
            src={product.images[0]}
            alt={product.name}
            priority={priority}
            className="transition-transform duration-500 group-hover:scale-110"
          />
          <div className="absolute left-2.5 top-2.5 flex flex-col gap-1.5">
            {product.isNew && <Badge variant="new">New</Badge>}
            {product.compareAtPrice && <Badge variant="sale">Sale</Badge>}
            {!product.inStock && <Badge variant="neutral">Sold Out</Badge>}
          </div>
          <motion.button
            ref={addButtonRef}
            onClick={handleQuickAdd}
            disabled={!product.inStock}
            data-cursor-hover
            aria-label={`Add ${product.name} to cart`}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            className={cn(
              "absolute bottom-2.5 right-2.5 flex h-9 w-9 items-center justify-center rounded-full bg-chili text-cream shadow-spice opacity-0 transition-opacity duration-200 group-hover:opacity-100 disabled:pointer-events-none disabled:opacity-0",
            )}
          >
            <Plus className="h-4 w-4" />
          </motion.button>
        </div>

        <div className="p-4">
          <p className="text-[11px] font-semibold uppercase tracking-wide text-tandoor/40">
            {product.category}
          </p>
          <h3 className="mt-1 font-display text-sm font-bold leading-snug text-tandoor sm:text-base">
            {product.name}
          </h3>
          {product.rating && (
            <div className="mt-1.5 flex items-center gap-1 text-xs text-tandoor/50">
              <Star className="h-3.5 w-3.5 fill-turmeric text-turmeric" />
              <span>{product.rating}</span>
              <span>({product.reviewCount})</span>
            </div>
          )}
          <div className="mt-2 flex items-center gap-2">
            <span className="font-display text-sm font-bold text-chili sm:text-base">
              {formatPKR(product.price)}
            </span>
            {product.compareAtPrice && (
              <span className="text-xs text-tandoor/40 line-through">
                {formatPKR(product.compareAtPrice)}
              </span>
            )}
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
