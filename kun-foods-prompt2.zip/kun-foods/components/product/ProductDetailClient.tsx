"use client";

import { useRef, useState } from "react";
import { Star, ShieldCheck, Truck, Flame } from "lucide-react";
import type { Product } from "@/types";
import ProductImage from "./ProductImage";
import ProductCard from "./ProductCard";
import QuantitySelector from "./QuantitySelector";
import Button from "@/components/ui/Button";
import Badge from "@/components/ui/Badge";
import ScrollReveal from "@/components/motion/ScrollReveal";
import { useCart } from "@/lib/cart-context";
import { useToast } from "@/components/ui/Toast";
import { formatPKR, cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";

const spiceLevelDots: Record<string, number> = {
  mild: 1,
  medium: 2,
  hot: 3,
  "extra-hot": 4,
};

interface ProductDetailClientProps {
  product: Product;
  relatedProducts: Product[];
}

export default function ProductDetailClient({ product, relatedProducts }: ProductDetailClientProps) {
  const [activeImage, setActiveImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const addButtonRef = useRef<HTMLButtonElement>(null);
  const { addItem } = useCart();
  const { showToast } = useToast();

  const handleAddToCart = () => {
    const rect = addButtonRef.current?.getBoundingClientRect();
    addItem(product, quantity, rect ? { src: product.images[activeImage], rect } : undefined);
    showToast({
      title: "Added to cart",
      description: `${quantity} × ${product.name}`,
      variant: "success",
    });
    setQuantity(1);
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="grid grid-cols-1 gap-10 lg:grid-cols-2 lg:gap-16">
        {/* Gallery — structured to support N images even though most mock
            products only have 1-2. Thumbnails only render if there's more
            than one image. */}
        <div>
          <div className="relative aspect-square overflow-hidden rounded-3xl bg-tandoor/5">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeImage}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.25 }}
                className="absolute inset-0"
              >
                <ProductImage
                  src={product.images[activeImage]}
                  alt={`${product.name} — image ${activeImage + 1}`}
                  priority
                  sizes="(max-width: 1024px) 100vw, 50vw"
                />
              </motion.div>
            </AnimatePresence>
          </div>
          {product.images.length > 1 && (
            <div className="mt-4 flex gap-3">
              {product.images.map((img, i) => (
                <button
                  key={img + i}
                  onClick={() => setActiveImage(i)}
                  data-cursor-hover
                  aria-label={`View image ${i + 1}`}
                  className={cn(
                    "relative h-16 w-16 shrink-0 overflow-hidden rounded-xl border-2 transition-colors",
                    activeImage === i ? "border-chili" : "border-transparent"
                  )}
                >
                  <ProductImage src={img} alt="" sizes="64px" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Details */}
        <div>
          <p className="text-xs font-semibold uppercase tracking-wide text-chili">
            {product.category}
          </p>
          <h1 className="mt-1 font-display text-3xl font-extrabold sm:text-4xl">{product.name}</h1>

          <div className="mt-3 flex flex-wrap items-center gap-3">
            {product.rating && (
              <div className="flex items-center gap-1 text-sm text-tandoor/60">
                <Star className="h-4 w-4 fill-turmeric text-turmeric" />
                <span className="font-semibold text-tandoor">{product.rating}</span>
                <span>({product.reviewCount} reviews)</span>
              </div>
            )}
            {product.spiceLevel && (
              <div className="flex items-center gap-1.5 text-sm text-tandoor/60">
                <Flame className="h-4 w-4 text-chili" />
                <div className="flex gap-0.5">
                  {[1, 2, 3, 4].map((i) => (
                    <span
                      key={i}
                      className={cn(
                        "h-1.5 w-4 rounded-full",
                        i <= spiceLevelDots[product.spiceLevel!] ? "bg-chili" : "bg-tandoor/10"
                      )}
                    />
                  ))}
                </div>
                <span className="capitalize">{product.spiceLevel.replace("-", " ")}</span>
              </div>
            )}
          </div>

          <div className="mt-5 flex items-baseline gap-3">
            <span className="font-display text-3xl font-extrabold text-chili">
              {formatPKR(product.price)}
            </span>
            {product.compareAtPrice && (
              <span className="text-lg text-tandoor/40 line-through">
                {formatPKR(product.compareAtPrice)}
              </span>
            )}
            <span className="text-sm text-tandoor/50">/ {product.weight}</span>
          </div>

          <p className="mt-5 leading-relaxed text-tandoor/70">{product.description}</p>

          {!product.inStock && (
            <div className="mt-4">
              <Badge variant="neutral">Currently sold out</Badge>
            </div>
          )}

          <div className="mt-7 flex flex-wrap items-center gap-4">
            <QuantitySelector quantity={quantity} onChange={setQuantity} />
            <Button
              ref={addButtonRef}
              size="lg"
              disabled={!product.inStock}
              onClick={handleAddToCart}
              className="flex-1 sm:flex-none"
            >
              {product.inStock ? "Add to Cart" : "Sold Out"}
            </Button>
          </div>

          <div className="mt-8 grid grid-cols-1 gap-3 border-t border-tandoor/10 pt-6 sm:grid-cols-2">
            <div className="flex items-start gap-2.5 text-sm text-tandoor/60">
              <Truck className="mt-0.5 h-4 w-4 shrink-0 text-chili" />
              <span>Delivered nationwide in 2–5 business days</span>
            </div>
            <div className="flex items-start gap-2.5 text-sm text-tandoor/60">
              <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-chili" />
              <span>Sealed for freshness, stone-ground to order</span>
            </div>
          </div>

          {product.ingredients && (
            <div className="mt-8 border-t border-tandoor/10 pt-6">
              <h2 className="font-display text-sm font-bold uppercase tracking-wide">
                Ingredients
              </h2>
              <p className="mt-2 text-sm text-tandoor/60">{product.ingredients.join(", ")}</p>
            </div>
          )}

          {product.usageTips && (
            <div className="mt-4">
              <h2 className="font-display text-sm font-bold uppercase tracking-wide">
                Usage Tip
              </h2>
              <p className="mt-2 text-sm text-tandoor/60">{product.usageTips}</p>
            </div>
          )}
        </div>
      </div>

      {relatedProducts.length > 0 && (
        <ScrollReveal className="mt-20">
          <h2 className="font-display text-2xl font-bold">You Might Also Like</h2>
          <div className="mt-6 grid grid-cols-2 gap-4 sm:gap-6 md:grid-cols-3 lg:grid-cols-4">
            {relatedProducts.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </ScrollReveal>
      )}
    </div>
  );
}
