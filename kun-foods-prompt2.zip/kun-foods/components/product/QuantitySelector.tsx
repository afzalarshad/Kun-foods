"use client";

import { Minus, Plus } from "lucide-react";

interface QuantitySelectorProps {
  quantity: number;
  onChange: (quantity: number) => void;
  min?: number;
  max?: number;
}

export default function QuantitySelector({ quantity, onChange, min = 1, max = 20 }: QuantitySelectorProps) {
  return (
    <div className="inline-flex items-center rounded-full border-2 border-tandoor/15">
      <button
        type="button"
        onClick={() => onChange(Math.max(min, quantity - 1))}
        disabled={quantity <= min}
        data-cursor-hover
        aria-label="Decrease quantity"
        className="p-3 text-tandoor/70 hover:text-chili disabled:opacity-30"
      >
        <Minus className="h-4 w-4" />
      </button>
      <span className="w-8 text-center font-display font-bold" aria-live="polite">
        {quantity}
      </span>
      <button
        type="button"
        onClick={() => onChange(Math.min(max, quantity + 1))}
        disabled={quantity >= max}
        data-cursor-hover
        aria-label="Increase quantity"
        className="p-3 text-tandoor/70 hover:text-chili disabled:opacity-30"
      >
        <Plus className="h-4 w-4" />
      </button>
    </div>
  );
}
