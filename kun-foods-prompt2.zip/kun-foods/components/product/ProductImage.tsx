"use client";

import { useState } from "react";
import Image from "next/image";
import { cn } from "@/lib/utils";

interface ProductImageProps {
  src: string;
  alt: string;
  className?: string;
  sizes?: string;
  priority?: boolean;
}

/**
 * Wraps next/image with a graceful fallback. The product catalogue
 * currently points at Unsplash placeholder photos (see the comment block
 * at the top of lib/mock-data.ts) — if a particular Unsplash URL ever
 * 404s, breaks, or is replaced before you've swapped in real product
 * photography, this renders a branded gradient placeholder instead of a
 * broken-image icon.
 */
export default function ProductImage({ src, alt, className, sizes, priority }: ProductImageProps) {
  const [errored, setErrored] = useState(false);

  if (errored) {
    return (
      <div
        className={cn(
          "flex items-center justify-center bg-gradient-to-br from-turmeric/25 via-saffron/15 to-chili/25 p-4 text-center",
          className
        )}
      >
        <span className="font-display text-sm font-semibold text-tandoor/40">{alt}</span>
      </div>
    );
  }

  return (
    <Image
      src={src}
      alt={alt}
      fill
      sizes={sizes ?? "(max-width: 768px) 50vw, 25vw"}
      priority={priority}
      className={cn("object-cover", className)}
      onError={() => setErrored(true)}
    />
  );
}
