"use client";

import { motion, type Variants } from "framer-motion";

interface ScrollRevealProps {
  children: React.ReactNode;
  className?: string;
  delay?: number;
  direction?: "up" | "left" | "right" | "none";
}

const distance = 28;

function getVariants(direction: ScrollRevealProps["direction"]): Variants {
  const offset =
    direction === "up"
      ? { y: distance }
      : direction === "left"
      ? { x: -distance }
      : direction === "right"
      ? { x: distance }
      : {};

  return {
    hidden: { opacity: 0, ...offset },
    visible: { opacity: 1, x: 0, y: 0 },
  };
}

/**
 * Generic "fade + slide in as it enters the viewport" wrapper used
 * throughout the home, shop, and blog pages. `once: true` means the
 * animation fires the first time an element scrolls into view and never
 * replays — avoids the distracting re-trigger-on-scroll-up behaviour, and
 * keeps the observer from doing continuous work after the first reveal.
 */
export default function ScrollReveal({
  children,
  className,
  delay = 0,
  direction = "up",
}: ScrollRevealProps) {
  return (
    <motion.div
      className={className}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: "-80px" }}
      variants={getVariants(direction)}
      transition={{ duration: 0.6, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}
