"use client";

import { forwardRef } from "react";
import Link from "next/link";
import { motion, type HTMLMotionProps } from "framer-motion";
import { Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

// A <Link> rendered through framer-motion so it can take the same
// whileHover/whileTap props as the plain <button> below.
const MotionLink = motion(Link);

type ButtonVariant = "primary" | "secondary" | "outline" | "ghost";
type ButtonSize = "sm" | "md" | "lg";

interface ButtonProps extends HTMLMotionProps<"button"> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  isLoading?: boolean;
  /** When set, Button renders as a Next.js <Link> instead of a <button> —
   * avoids ever nesting a <button> inside an <a>, which is invalid HTML. */
  href?: string;
}

const variantClasses: Record<ButtonVariant, string> = {
  primary:
    "bg-chili text-cream shadow-spice hover:bg-chili/90 disabled:hover:bg-chili",
  secondary:
    "bg-turmeric text-tandoor hover:bg-turmeric/90 disabled:hover:bg-turmeric",
  outline:
    "border-2 border-chili text-chili bg-transparent hover:bg-chili/10",
  ghost: "bg-transparent text-tandoor hover:bg-tandoor/5",
};

const sizeClasses: Record<ButtonSize, string> = {
  sm: "text-sm px-4 py-2 rounded-full",
  md: "text-base px-6 py-3 rounded-full",
  lg: "text-lg px-8 py-4 rounded-full",
};

/**
 * Primary interactive control. Uses Framer Motion's whileHover/whileTap
 * for a small "sizzle" — a subtle scale + lift, not a bounce — so it
 * feels energetic without being distracting when repeated across a page
 * full of product cards.
 */
const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  (
    { className, variant = "primary", size = "md", isLoading, children, disabled, href, ...props },
    ref
  ) => {
    const classes = cn(
      "inline-flex items-center justify-center gap-2 font-display font-semibold tracking-tight transition-colors disabled:opacity-50 disabled:cursor-not-allowed",
      variantClasses[variant],
      sizeClasses[size],
      className
    );

    if (href) {
      // Only DOM-safe/anchor-relevant props from `...props` make sense on a
      // link (e.g. onClick); button-only attributes like `type` or
      // `disabled` don't apply here.
      const { onClick } = props as { onClick?: React.MouseEventHandler };
      return (
        <MotionLink
          href={href}
          onClick={onClick}
          data-cursor-hover
          whileHover={{ scale: 1.03, y: -2 }}
          whileTap={{ scale: 0.97 }}
          transition={{ type: "spring", stiffness: 400, damping: 20 }}
          className={classes}
        >
          {children}
        </MotionLink>
      );
    }

    return (
      <motion.button
        ref={ref}
        data-cursor-hover
        whileHover={{ scale: disabled ? 1 : 1.03, y: disabled ? 0 : -2 }}
        whileTap={{ scale: disabled ? 1 : 0.97 }}
        transition={{ type: "spring", stiffness: 400, damping: 20 }}
        disabled={disabled || isLoading}
        className={classes}
        {...props}
      >
        {isLoading && <Loader2 className="h-4 w-4 animate-spin" aria-hidden />}
        {children}
      </motion.button>
    );
  }
);
Button.displayName = "Button";

export default Button;
