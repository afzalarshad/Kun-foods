"use client";

import { forwardRef } from "react";
import { motion, type HTMLMotionProps } from "framer-motion";
import { cn } from "@/lib/utils";

interface CardProps extends HTMLMotionProps<"div"> {
  hoverLift?: boolean;
}

/**
 * Base surface used for product cards, blog cards, info panels.
 * `hoverLift` gives a gentle rise + shadow bloom on hover — disable it
 * for cards that aren't clickable (e.g. static info panels).
 */
const Card = forwardRef<HTMLDivElement, CardProps>(
  ({ className, hoverLift = true, children, ...props }, ref) => {
    return (
      <motion.div
        ref={ref}
        data-cursor-hover={hoverLift ? true : undefined}
        whileHover={hoverLift ? { y: -6 } : undefined}
        transition={{ type: "spring", stiffness: 300, damping: 24 }}
        className={cn(
          "rounded-2xl border border-tandoor/10 bg-white/70 backdrop-blur-sm shadow-sm",
          hoverLift && "hover:shadow-spice-lg transition-shadow",
          className
        )}
        {...props}
      >
        {children}
      </motion.div>
    );
  }
);
Card.displayName = "Card";

export default Card;
