"use client";

import { createContext, useCallback, useContext, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { CheckCircle2, Info, XCircle, X } from "lucide-react";
import type { ToastMessage } from "@/types";
import { cn } from "@/lib/utils";

interface ToastContextValue {
  showToast: (toast: Omit<ToastMessage, "id">) => void;
}

const ToastContext = createContext<ToastContextValue | null>(null);

const icons = {
  success: CheckCircle2,
  error: XCircle,
  info: Info,
};

const variantClasses = {
  success: "border-masala/30 text-masala",
  error: "border-chili/30 text-chili",
  info: "border-saffron/30 text-saffron",
};

/**
 * Wrap the app in <ToastProvider> once (done in app/layout.tsx). Anywhere
 * deeper in the tree, call `const { showToast } = useToast()` and fire
 * showToast({ title: "Added to cart", variant: "success" }).
 */
export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const showToast = useCallback((toast: Omit<ToastMessage, "id">) => {
    const id = crypto.randomUUID();
    setToasts((prev) => [...prev, { ...toast, id }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  }, []);

  const dismiss = (id: string) => setToasts((prev) => prev.filter((t) => t.id !== id));

  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}
      <div className="pointer-events-none fixed bottom-4 right-4 z-[200] flex w-full max-w-sm flex-col gap-2 sm:bottom-6 sm:right-6">
        <AnimatePresence>
          {toasts.map((toast) => {
            const Icon = icons[toast.variant ?? "info"];
            return (
              <motion.div
                key={toast.id}
                layout
                initial={{ opacity: 0, y: 40, scale: 0.9 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, x: 60, scale: 0.9 }}
                transition={{ type: "spring", stiffness: 350, damping: 26 }}
                className={cn(
                  "pointer-events-auto flex items-start gap-3 rounded-xl border-2 bg-white p-4 shadow-spice-lg",
                  variantClasses[toast.variant ?? "info"]
                )}
              >
                <Icon className="mt-0.5 h-5 w-5 shrink-0" aria-hidden />
                <div className="flex-1">
                  <p className="font-display text-sm font-bold text-tandoor">{toast.title}</p>
                  {toast.description && (
                    <p className="mt-0.5 text-sm text-tandoor/70">{toast.description}</p>
                  )}
                </div>
                <button
                  onClick={() => dismiss(toast.id)}
                  aria-label="Dismiss notification"
                  data-cursor-hover
                  className="text-tandoor/40 hover:text-tandoor"
                >
                  <X className="h-4 w-4" />
                </button>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error("useToast must be used within a ToastProvider");
  return ctx;
}
