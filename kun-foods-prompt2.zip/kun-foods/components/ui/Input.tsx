"use client";

import { forwardRef, useId, type InputHTMLAttributes } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
}

const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ className, label, error, id, ...props }, ref) => {
    const generatedId = useId();
    const inputId = id ?? generatedId;

    return (
      <div className="w-full">
        {label && (
          <label
            htmlFor={inputId}
            className="mb-1.5 block text-sm font-medium text-tandoor/80"
          >
            {label}
          </label>
        )}
        <motion.input
          ref={ref}
          id={inputId}
          data-cursor-hover
          animate={error ? { x: [0, -6, 6, -4, 4, 0] } : { x: 0 }}
          transition={{ duration: 0.4 }}
          aria-invalid={!!error}
          className={cn(
            "w-full rounded-xl border-2 border-tandoor/15 bg-white px-4 py-3 text-tandoor placeholder:text-tandoor/40 outline-none transition-colors focus:border-chili",
            error && "border-chili",
            className
          )}
          {...props}
        />
        {error && (
          <p role="alert" className="mt-1.5 text-sm text-chili">
            {error}
          </p>
        )}
      </div>
    );
  }
);
Input.displayName = "Input";

export default Input;
