import type { HTMLAttributes } from "react";
import { cn } from "@/lib/utils";

type BadgeVariant = "sale" | "new" | "mild" | "medium" | "hot" | "extra-hot" | "neutral";

const variantClasses: Record<BadgeVariant, string> = {
  sale: "bg-chili text-cream",
  new: "bg-masala text-cream",
  mild: "bg-turmeric/20 text-turmeric",
  medium: "bg-saffron/20 text-saffron",
  hot: "bg-chili/20 text-chili",
  "extra-hot": "bg-chili text-cream",
  neutral: "bg-tandoor/10 text-tandoor",
};

interface BadgeProps extends HTMLAttributes<HTMLSpanElement> {
  variant?: BadgeVariant;
}

export default function Badge({ variant = "neutral", className, children, ...props }: BadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-3 py-1 text-xs font-semibold uppercase tracking-wide",
        variantClasses[variant],
        className
      )}
      {...props}
    >
      {children}
    </span>
  );
}
