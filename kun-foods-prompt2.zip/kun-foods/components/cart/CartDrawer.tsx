"use client";

import { useEffect } from "react";
import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import { Minus, Plus, X, ShoppingBag, Trash2 } from "lucide-react";
import { useCart } from "@/lib/cart-context";
import ProductImage from "@/components/product/ProductImage";
import Button from "@/components/ui/Button";
import { formatPKR } from "@/lib/utils";

export default function CartDrawer() {
  const { items, isOpen, closeCart, subtotal, updateQuantity, removeItem } = useCart();

  useEffect(() => {
    if (!isOpen) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && closeCart();
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [isOpen, closeCart]);

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            className="fixed inset-0 z-[150] bg-tandoor/50 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={closeCart}
            aria-hidden
          />
          <motion.aside
            role="dialog"
            aria-modal="true"
            aria-label="Shopping cart"
            className="fixed right-0 top-0 z-[151] flex h-full w-full max-w-md flex-col bg-cream shadow-spice-lg"
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", stiffness: 320, damping: 34 }}
          >
            <div className="flex items-center justify-between border-b border-tandoor/10 px-5 py-4">
              <h2 className="font-display text-lg font-bold">
                Your Cart {items.length > 0 && `(${items.length})`}
              </h2>
              <button
                onClick={closeCart}
                data-cursor-hover
                aria-label="Close cart"
                className="rounded-full p-2 text-tandoor/60 hover:bg-tandoor/10 hover:text-tandoor"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {items.length === 0 ? (
              <div className="flex flex-1 flex-col items-center justify-center gap-3 px-6 text-center">
                <ShoppingBag className="h-10 w-10 text-tandoor/25" />
                <p className="font-display font-semibold text-tandoor/70">Your cart is empty</p>
                <p className="text-sm text-tandoor/50">
                  Add a few masalas and they&rsquo;ll show up here.
                </p>
                <Button href="/shop" size="sm" className="mt-2" onClick={closeCart}>
                  Browse the Shop
                </Button>
              </div>
            ) : (
              <>
                <ul className="flex-1 overflow-y-auto px-5 py-4">
                  <AnimatePresence initial={false}>
                    {items.map((item) => (
                      <motion.li
                        key={item.product.id}
                        layout
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.25 }}
                        className="flex gap-3 border-b border-tandoor/10 py-4 last:border-0"
                      >
                        <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-xl">
                          <ProductImage
                            src={item.product.images[0]}
                            alt={item.product.name}
                            sizes="64px"
                          />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-start justify-between gap-2">
                            <Link
                              href={`/shop/${item.product.slug}`}
                              onClick={closeCart}
                              data-cursor-hover
                              className="font-display text-sm font-bold leading-snug hover:text-chili"
                            >
                              {item.product.name}
                            </Link>
                            <button
                              onClick={() => removeItem(item.product.id)}
                              data-cursor-hover
                              aria-label={`Remove ${item.product.name} from cart`}
                              className="shrink-0 text-tandoor/40 hover:text-chili"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                          <p className="mt-0.5 text-xs text-tandoor/50">{item.product.weight}</p>
                          <div className="mt-2 flex items-center justify-between">
                            <div className="flex items-center rounded-full border border-tandoor/15">
                              <button
                                onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                                data-cursor-hover
                                aria-label="Decrease quantity"
                                className="p-1.5 text-tandoor/70 hover:text-chili"
                              >
                                <Minus className="h-3.5 w-3.5" />
                              </button>
                              <span className="w-6 text-center text-sm font-semibold">
                                {item.quantity}
                              </span>
                              <button
                                onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                                data-cursor-hover
                                aria-label="Increase quantity"
                                className="p-1.5 text-tandoor/70 hover:text-chili"
                              >
                                <Plus className="h-3.5 w-3.5" />
                              </button>
                            </div>
                            <span className="font-display text-sm font-bold text-chili">
                              {formatPKR(item.product.price * item.quantity)}
                            </span>
                          </div>
                        </div>
                      </motion.li>
                    ))}
                  </AnimatePresence>
                </ul>

                <div className="border-t border-tandoor/10 px-5 py-5">
                  <div className="mb-1 flex items-center justify-between text-sm text-tandoor/60">
                    <span>Shipping &amp; taxes</span>
                    <span>Calculated at checkout</span>
                  </div>
                  <div className="mb-4 flex items-center justify-between">
                    <span className="font-display font-bold">Subtotal</span>
                    <span className="font-display text-lg font-bold text-chili">
                      {formatPKR(subtotal)}
                    </span>
                  </div>
                  <Button className="w-full" size="lg">
                    Checkout
                  </Button>
                </div>
              </>
            )}
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}
