// Shared types used across the app. Once Supabase is wired up (a later
// prompt), these should mirror the generated database types — for now
// they describe the shape of our mock data.

export type SpiceLevel = "mild" | "medium" | "hot" | "extra-hot";

export interface Product {
  id: string;
  slug: string;
  name: string;
  shortDescription: string;
  description: string; // longer copy for the PDP
  price: number; // in PKR
  compareAtPrice?: number; // for "on sale" strike-through pricing
  weight: string; // e.g. "200g"
  images: string[]; // gallery — index 0 is the primary/card image
  category: string;
  spiceLevel?: SpiceLevel;
  isNew?: boolean;
  inStock: boolean;
  rating?: number; // 0–5
  reviewCount?: number;
  ingredients?: string[];
  usageTips?: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface ToastMessage {
  id: string;
  title: string;
  description?: string;
  variant?: "success" | "error" | "info";
}

export interface BlogPost {
  slug: string;
  title: string;
  excerpt: string;
  content: string[]; // paragraphs
  coverImage: string;
  author: string;
  date: string; // ISO
  readTime: string;
  category: string;
}
